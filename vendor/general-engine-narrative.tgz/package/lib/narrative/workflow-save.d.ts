import { type CompiledStory, type GameSession, type SessionSnapshot } from './workflow-types.js';
export interface NarrativeSaveRecord {
    slotId: string;
    snapshot: SessionSnapshot;
    savedAt: string;
    label?: string;
}
export interface NarrativeSaveEntry {
    slotId: string;
    gameId: string;
    contentVersion: string;
    savedAt: string;
    label?: string;
}
export interface NarrativeSaveStore {
    list(gameId?: string): Promise<NarrativeSaveEntry[]>;
    read(slotId: string): Promise<NarrativeSaveRecord | null>;
    write(record: NarrativeSaveRecord): Promise<void>;
    delete(slotId: string): Promise<boolean>;
}
export type ContentMigration = (snapshot: SessionSnapshot, compiled: CompiledStory) => SessionSnapshot;
export interface PrepareSnapshotOptions {
    migrateContent?: ContentMigration;
    isModuleVersionCompatible?: (savedVersion: string, currentVersion: string) => boolean;
    isEngineVersionCompatible?: (savedVersion: string, currentVersion: string) => boolean;
}
/** Validate only the JSON/save envelope. Story cursor checks are separate. */
export declare function validateNarrativeSnapshot(value: unknown): asserts value is SessionSnapshot;
/** Validate cursor invariants against the currently compiled story. */
export declare function validateNarrativeSnapshotForStory(snapshot: SessionSnapshot, compiled: CompiledStory): void;
/** Validate, migrate and detach a save before handing it to a session. */
export declare function prepareNarrativeSnapshot(input: SessionSnapshot, compiled: CompiledStory, options?: PrepareSnapshotOptions): SessionSnapshot;
export declare function serializeNarrativeSnapshot(snapshot: SessionSnapshot): string;
export declare function parseNarrativeSnapshot(serialized: string): SessionSnapshot;
export declare const validateSnapshot: typeof validateNarrativeSnapshot;
export declare const validateSnapshotForStory: typeof validateNarrativeSnapshotForStory;
export declare const prepareSnapshot: typeof prepareNarrativeSnapshot;
export declare const serializeSnapshot: typeof serializeNarrativeSnapshot;
export declare const parseSnapshot: typeof parseNarrativeSnapshot;
export declare class MemoryNarrativeSaveStore implements NarrativeSaveStore {
    private readonly records;
    list(gameId?: string): Promise<NarrativeSaveEntry[]>;
    read(slotId: string): Promise<NarrativeSaveRecord | null>;
    write(record: NarrativeSaveRecord): Promise<void>;
    delete(slotId: string): Promise<boolean>;
}
export declare class LocalStorageNarrativeSaveStore implements NarrativeSaveStore {
    private readonly prefix;
    private storage?;
    private readonly memory;
    constructor(storage?: Pick<Storage, 'length' | 'key' | 'getItem' | 'setItem' | 'removeItem'>, prefix?: string);
    list(gameId?: string): Promise<NarrativeSaveEntry[]>;
    read(slotId: string): Promise<NarrativeSaveRecord | null>;
    write(record: NarrativeSaveRecord): Promise<void>;
    delete(slotId: string): Promise<boolean>;
    private toEntry;
    private key;
}
export interface SessionSaveOptions {
    label?: string;
    savedAt?: string;
}
export declare function saveSession(store: NarrativeSaveStore, slotId: string, session: GameSession, options?: SessionSaveOptions): Promise<NarrativeSaveRecord>;
