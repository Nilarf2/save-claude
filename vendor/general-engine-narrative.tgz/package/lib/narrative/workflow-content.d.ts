import { type Action, type AdventureModule, type CompiledStory, type Condition, type ModuleRegistry, type Story, type ValueExpression } from './workflow-types.js';
export interface NarrativeDiagnostic {
    code: string;
    message: string;
    path: string;
    severity: 'error' | 'warning';
}
export interface NarrativeValidationResult {
    diagnostics: NarrativeDiagnostic[];
    valid: boolean;
}
/** Validate a serializable story graph and all registered extension payloads. */
export declare function validateStory(input: unknown, modules?: readonly AdventureModule[] | ModuleRegistry): NarrativeValidationResult;
/** Validate then detach and freeze authoring data before runtime use. */
export declare function compileStory(input: Story, modules?: readonly AdventureModule[]): CompiledStory;
export declare function formatDiagnostics(result: NarrativeValidationResult, format?: 'text' | 'json'): string;
export declare function validateExpressionForContent(expression: ValueExpression | Condition | Action): boolean;
