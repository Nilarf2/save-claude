import type { AdventureModule } from './workflow-types.js';
export interface NarrativeAuthoringIO {
    readText(path: string): Promise<string>;
    writeText(path: string, text: string): Promise<void>;
    mkdir(path: string): Promise<void>;
    log(message: string): void;
    error(message: string): void;
}
export interface NarrativeAuthoringOptions {
    modules?: readonly AdventureModule[];
    loadModules?: (path: string) => Promise<readonly AdventureModule[]>;
}
export interface NarrativeAuthoringResult {
    code: number;
    output?: string;
}
/** Inspect a story without executing extension code or mutating author input. */
export declare function inspectStory(story: unknown, modules?: readonly AdventureModule[]): Record<string, unknown>;
/** Injectable authoring workflow for validate, inspect and compile commands. */
export declare function runNarrativeAuthoring(args: readonly string[], io: NarrativeAuthoringIO, options?: NarrativeAuthoringOptions): Promise<NarrativeAuthoringResult>;
