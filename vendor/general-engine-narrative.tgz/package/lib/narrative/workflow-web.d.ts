import type { AssetDefinition, AudioChannel, RuntimeEffect, SessionSnapshot, SessionState, Story } from './workflow-types.js';
export type AssetResolver = (assetId: string, definition?: AssetDefinition) => string | undefined | null | Promise<string | undefined | null>;
export interface AudioFailureContext {
    operation: string;
    assetId?: string;
    channel?: AudioChannel;
}
export interface AudioAdapterOptions {
    assets?: Story['assets'];
    resolveAsset?: AssetResolver;
    onError?: (error: unknown, context: AudioFailureContext) => void;
    createAudio?: (source: string) => HTMLAudioElement;
    fadeTickMs?: number;
}
export interface FadeOptions {
    fadeMs?: number;
}
export interface WebMusicOptions extends FadeOptions {
    loop?: boolean;
    volume?: number;
    channel?: AudioChannel;
}
export interface AudioPort {
    playMusic(assetId: string, options?: WebMusicOptions): Promise<void>;
    playAmbience(assetId: string, options?: Omit<WebMusicOptions, 'channel'>): Promise<void>;
    playSfx(assetId: string, volume?: number): Promise<void>;
    stopMusic(options?: FadeOptions): Promise<void>;
    stopAmbience(options?: FadeOptions): Promise<void>;
    pause(channel?: AudioChannel): void;
    resume(channel?: AudioChannel): Promise<void>;
    setVolume(channel: AudioChannel, volume: number, fadeMs?: number): Promise<void>;
    unlock(): Promise<void>;
    handleEffect(effect: RuntimeEffect): Promise<void>;
    reconcile(snapshot: SessionSnapshot | SessionState): Promise<void>;
    dispose(): void;
}
/**
 * Browser audio adapter for serializable narrative effects. Audio creation and
 * asset lookup are injected so the adapter can be tested without a DOM.
 */
export declare class WebAudioAdapter implements AudioPort {
    private readonly options;
    private readonly channels;
    private readonly generations;
    private readonly fades;
    private readonly soundEffects;
    private readonly blockedEffects;
    private readonly createAudio;
    private disposed;
    constructor(options?: AudioAdapterOptions);
    playMusic(assetId: string, options?: WebMusicOptions): Promise<void>;
    playAmbience(assetId: string, options?: Omit<WebMusicOptions, 'channel'>): Promise<void>;
    playSfx(assetId: string, volume?: number): Promise<void>;
    stopMusic(options?: FadeOptions): Promise<void>;
    stopAmbience(options?: FadeOptions): Promise<void>;
    stop(channel: AudioChannel, options?: FadeOptions): Promise<void>;
    pause(channel?: AudioChannel): void;
    resume(channel?: AudioChannel): Promise<void>;
    setVolume(channel: AudioChannel, volume: number, fadeMs?: number): Promise<void>;
    unlock(): Promise<void>;
    handleEffect(effect: RuntimeEffect): Promise<void>;
    reconcile(snapshot: SessionSnapshot | SessionState): Promise<void>;
    dispose(): void;
    private playTrack;
    private resolveAsset;
    private tryPlay;
    private fadeTo;
    private nextGeneration;
    private generation;
    private cancelFade;
    private releaseTrack;
    private releaseSfx;
    private clamp;
    private report;
}
export interface NarrativeWebAdapterOptions {
    audio?: AudioPort;
    onScene?: (scene: {
        id: string;
        background?: string;
    }) => void | Promise<void>;
    onModuleRequest?: (request: Extract<RuntimeEffect, {
        type: 'module.request';
    }>['request']) => void | Promise<void>;
    onCheckpoint?: (name: string | undefined) => void | Promise<void>;
    onEvent?: (event: {
        type: string;
        payload?: import('./workflow-types.js').JsonValue;
    }) => void | Promise<void>;
    onEffect?: (effect: RuntimeEffect) => void | Promise<void>;
}
/** Dispatches session effects to host-owned scene, module and audio adapters. */
export declare class NarrativeWebAdapter {
    private readonly options;
    constructor(options?: NarrativeWebAdapterOptions);
    apply(effects: readonly RuntimeEffect[], events?: readonly {
        type: string;
        payload?: import('./workflow-types.js').JsonValue;
    }[]): Promise<void>;
    reconcile(snapshot: SessionSnapshot | SessionState): Promise<void>;
    dispose(): void;
}
export declare function createNarrativeWebAdapter(options?: NarrativeWebAdapterOptions): NarrativeWebAdapter;
