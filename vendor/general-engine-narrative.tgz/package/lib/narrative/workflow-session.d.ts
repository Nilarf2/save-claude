import { type AdventureModule, type CompiledStory, type GameSession, type SessionOptions, type SessionSnapshot, type Story } from './workflow-types.js';
/** Create a deterministic, saveable session from content or precompiled content. */
export declare function createNarrativeSession(input: CompiledStory | Story, modulesOrOptions?: readonly AdventureModule[] | SessionOptions, maybeOptions?: SessionOptions): GameSession;
export declare const createSession: typeof createNarrativeSession;
export default createNarrativeSession;
export declare function parseNarrativeSnapshot(serialized: string): SessionSnapshot;
export declare function serializeNarrativeSnapshot(snapshot: SessionSnapshot): string;
